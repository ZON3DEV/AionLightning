@echo off
echo === Fork AionLightning 7.8 -> akvamarins 8.0 Merygen ===
git clone --recursive -b 7.8.0 https://github.com/ZON3DEV/AionLightning.git aion-8.0-merygen
cd aion-8.0-merygen
git remote rename origin upstream
git remote add origin https://github.com/akvamarins/aion-8.0-merygen.git
echo Copying Merygen custom files...
xcopy /E /Y ..\AL-Game AL-Game\
xcopy /E /Y ..\config config\
xcopy /E /Y ..\data data\
xcopy /E /Y ..\sql sql\
echo Now build: mvn clean package
pause
