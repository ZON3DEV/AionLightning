package org.haion.tools.databuilders.interfaces;

public class MeshInfo {
	public int meshIdx;
	public float[] matrix;
}
