# Aion 7.8 Fork -> 8.0 Merygen x3 Custom
**Original:** https://github.com/ZON3DEV/AionLightning (branch 7.8.0)  
**Fork for:** https://github.com/akvamarins/aion-8.0-merygen  
**Admin:** Merygen (access 3)  
**Rates:** x3 XP/Drop/AP/Quest, x2 GP  
**MaxLevel:** 80 (7.8 base, ready for 8.0)  
**Stigma:** 6 slots FINAL

## Why 7.8 base?
Public 8.0 emulator does NOT exist!  
- beyond-aion/beyaion = 4.8
- AionLightning 7.8.0 = closest to 8.0
- Germany = 7.3

So we take 7.8 as base and dopilim to 8.0!

## What is changed from original 7.8?
1. **PlayerExperienceTable.java FINAL 6 slots** - your file:
   - 20=0, 30=1, 40=2, 45=3, 50=4, 55=5, 55+=6
   - Fixed BOM and `id` attribute errors
2. **Rates x3** in `config/main/rates.properties`
3. **Admin Merygen** - auto created in SQL
4. **Custom quests** 80001, 80005, 80010 for Aparanta / 6th slot

## How to fork and build (dopilit)

### 1. Fork original 7.8:
```bash
git clone --recursive -b 7.8.0 https://github.com/ZON3DEV/AionLightning.git aion-8.0-merygen
cd aion-8.0-merygen
git remote rename origin upstream
git remote add origin https://github.com/akvamarins/aion-8.0-merygen.git
```

### 2. Apply our changes:
Copy from this repo:
- `AL-Game/src/main/java/com/aionemu/gameserver/dataholders/PlayerExperienceTable.java` -> to same path
- `config/` -> rates and admin
- `data/static_data/quests/custom/` -> custom quests

### 3. Build:
```bash
mvn clean package -DskipTests
# result in AL-Game/target/
```

### 4. DB:
Import `sql/aion_80_*.sql` - admin Merygen already inside.

### 5. Client:
Client 7.8/8.0: https://mega.nz/folder/wxMRXZDS#qMsKJlkyYUNp_TQln2EZlg  
Patch: https://github.com/beyond-aion/aion-version-dll/releases/latest -> bin32 & bin64

## To Do for 8.0 (dopilit list):
- [ ] Update skill templates to 8.0
- [ ] Aparanta map spawns
- [ ] Kerub quests
- [ ] Balance for 80 cap

## Credits
- Base: ZON3DEV / AionLightning
- Custom: Merygen
- PlayerExperienceTable FINAL: akvamarins
