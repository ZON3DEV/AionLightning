package org.haion.tools.databuilders.interfaces.server;

public interface IAionGeoMeshDataBlock
{
}
