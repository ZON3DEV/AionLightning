package org.haion.tools.databuilders.interfaces;

public class PakFileFormatException extends AionException {
	private static final long serialVersionUID = 1L;

	public PakFileFormatException(String string) {
		super(string);
	}
}
