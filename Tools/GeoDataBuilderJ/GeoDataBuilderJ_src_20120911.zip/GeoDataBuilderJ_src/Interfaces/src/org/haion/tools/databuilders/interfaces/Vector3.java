package org.haion.tools.databuilders.interfaces;

public class Vector3 {
	public float x;
	public float y;
	public float z;
}
