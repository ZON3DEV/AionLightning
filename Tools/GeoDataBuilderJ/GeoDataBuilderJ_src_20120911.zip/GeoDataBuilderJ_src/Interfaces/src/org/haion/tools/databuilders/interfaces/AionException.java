package org.haion.tools.databuilders.interfaces;

public class AionException extends Exception {
	private static final long serialVersionUID = 1L;

	public AionException(String string) {
		super(string);
	}
}
