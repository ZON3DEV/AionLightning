#!/bin/bash
# Fork 7.8 -> 8.0 Merygen
git clone --recursive -b 7.8.0 https://github.com/ZON3DEV/AionLightning.git aion-8.0-merygen
cd aion-8.0-merygen
git remote rename origin upstream
git remote add origin https://github.com/akvamarins/aion-8.0-merygen.git
cp -r ../AL-Game/src/main/java/com/aionemu/gameserver/dataholders/PlayerExperienceTable.java AL-Game/src/main/java/com/aionemu/gameserver/dataholders/
cp -r ../config/* config/
cp -r ../data/* data/
cp -r ../sql/* sql/ 2>/dev/null || true
echo "Ready to dopilit! Run mvn clean package"
