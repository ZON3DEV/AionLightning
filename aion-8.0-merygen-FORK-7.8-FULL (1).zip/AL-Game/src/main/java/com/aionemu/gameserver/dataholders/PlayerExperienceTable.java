package com.aionemu.gameserver.dataholders;

import java.util.List;
import javax.xml.bind.annotation.*;
import com.aionemu.gameserver.model.templates.ExpTemplate;

@XmlRootElement(name = "player_experience_table")
@XmlAccessorType(XmlAccessType.FIELD)
public class PlayerExperienceTable {

    @XmlElement(name = "player_experience")
    private List<ExpTemplate> expTemplates;

    @XmlElement(name = "exp")
    private List<Long> exps;

    @XmlElement(name = "exp")
    private List<Long> oldExps;

    @XmlTransient
    private List<Long> getExpsInternal() {
        if (exps != null) return exps;
        return oldExps;
    }

    @XmlTransient
    private int maxLevel = 0;

    void afterUnmarshal(javax.xml.bind.Unmarshaller u, Object parent) {
        if (expTemplates != null && !expTemplates.isEmpty()) {
            maxLevel = expTemplates.size();
        } else {
            List<Long> e = getExpsInternal();
            if (e != null) maxLevel = e.size();
        }
    }

    public int getMaxLevel() {
        if (maxLevel > 0) return maxLevel;
        if (expTemplates != null && !expTemplates.isEmpty()) return expTemplates.size();
        List<Long> e = getExpsInternal();
        if (e != null) return e.size();
        return 80; // 7.8 base -> 8.0 Merygen FINAL 6 slots
    }

    public long getStartExpForLevel(int level) {
        return getExpForLevel(level);
    }

    public long getExpForLevel(int level) {
        if (level < 1) return 0;
        if (expTemplates != null && !expTemplates.isEmpty()) {
            for (ExpTemplate t : expTemplates) {
                if (t.getLevel() == level) return t.getExp();
            }
            if (level <= expTemplates.size()) {
                return expTemplates.get(level - 1).getExp();
            }
            return expTemplates.get(expTemplates.size() - 1).getExp();
        }
        List<Long> e = getExpsInternal();
        if (e != null && level <= e.size()) {
            return e.get(level - 1);
        }
        return 0;
    }

    public int getLevelForExp(long exp) {
        int level = 1;
        int max = getMaxLevel();
        if (expTemplates != null && !expTemplates.isEmpty()) {
            for (ExpTemplate t : expTemplates) {
                if (exp < t.getExp()) break;
                level = t.getLevel();
            }
            return Math.min(level, max);
        }
        List<Long> e = getExpsInternal();
        if (e != null) {
            for (int i = 0; i < e.size(); i++) {
                if (exp < e.get(i)) break;
                level = i + 1;
            }
        }
        return Math.min(level, max);
    }

    public int getStigmaSlotForLevel(int level) {
        if (expTemplates != null && !expTemplates.isEmpty()) {
            for (ExpTemplate t : expTemplates) {
                if (t.getLevel() == level) {
                    return t.getStigmaSlot();
                }
            }
        }
        if (level < 20) return 0;
        if (level < 30) return 1;
        if (level < 40) return 2;
        if (level < 45) return 3;
        if (level < 50) return 4;
        if (level < 55) return 5;
        return 6;
    }

    public int getAdvStigmaSlotForLevel(int level) {
        if (expTemplates != null && !expTemplates.isEmpty()) {
            for (ExpTemplate t : expTemplates) {
                if (t.getLevel() == level) {
                    return t.getAdvStigmaSlot();
                }
            }
        }
        if (level >= 55) return 6;
        return 0;
    }

    public int size() { return getMaxLevel(); }

    public List<ExpTemplate> getExpTemplates() { return expTemplates; }
    public List<Long> getExps() { return getExpsInternal(); }
}
