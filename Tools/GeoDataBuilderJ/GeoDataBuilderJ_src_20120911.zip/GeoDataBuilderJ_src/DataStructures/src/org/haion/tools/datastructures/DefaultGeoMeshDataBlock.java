package org.haion.tools.datastructures;

import org.haion.tools.databuilders.interfaces.server.IAionGeoMeshDataBlock;

public class DefaultGeoMeshDataBlock implements IAionGeoMeshDataBlock {

}
