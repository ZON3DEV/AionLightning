package org.haion.tools.databuilders.interfaces;

public class MeshData {
	public Vector3[] vertices;
	public MeshFace[] indices;
}
