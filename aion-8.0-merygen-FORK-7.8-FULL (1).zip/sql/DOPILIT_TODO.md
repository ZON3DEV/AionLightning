# Chto dopilit dlya 8.0

1. PlayerExperienceTable.java - GOTOVO FINAL 6 slotov
2. Rates x3 - GOTOVO
3. Admin Merygen - GOTOVO
4. Custom quests - GOTOVO
5. Skill templates 8.0 - TODO: vzyat iz klienta 8.0
6. Aparanta spawns - TODO
7. Balance 80 lvl - TODO
