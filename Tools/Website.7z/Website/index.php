<?php
// ServerAion Web by Pr00f & Sky (serveraion.ru)
require "header.php";
?>

<div class="case">
	<div class="content">
		<?php require "news.php";?>
	</div>
    
<?php require "sidebar.php"; ?>
</div>

<?php require "footer.php"; ?>