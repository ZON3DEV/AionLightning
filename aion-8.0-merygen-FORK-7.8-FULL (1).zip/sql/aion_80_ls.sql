-- LS for akvamarins fork 7.8->8.0
CREATE DATABASE IF NOT EXISTS al_server_ls CHARACTER SET utf8mb4;
USE al_server_ls;
INSERT INTO account_data (name, access_level) VALUES ('Merygen',3) ON DUPLICATE KEY UPDATE access_level=3;
