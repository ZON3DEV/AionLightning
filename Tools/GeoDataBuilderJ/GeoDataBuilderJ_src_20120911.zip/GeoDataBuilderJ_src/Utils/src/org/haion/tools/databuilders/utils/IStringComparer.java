package org.haion.tools.databuilders.utils;

public interface IStringComparer {
	boolean compare(String s1, String s2);
}
