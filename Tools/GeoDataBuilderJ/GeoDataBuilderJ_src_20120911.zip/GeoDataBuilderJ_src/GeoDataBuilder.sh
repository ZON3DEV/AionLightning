java -jar GeoDataBuilder.jar -keep_tmp /media/Disk6/Games/AionMax30
