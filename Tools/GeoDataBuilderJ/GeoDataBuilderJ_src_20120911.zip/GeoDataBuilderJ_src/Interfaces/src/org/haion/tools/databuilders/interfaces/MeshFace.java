package org.haion.tools.databuilders.interfaces;

public class MeshFace {
	public int v0;
	public int v1;
	public int v2;
}
