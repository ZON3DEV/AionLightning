<!-- ServerAion Web by Pr00f & Sky (serveraion.ru) -->
<?php
    // close Mysql connections
    if (isset($sql_gs)) $sql_gs->close();
    if (isset($sql_ls)) $sql_ls->close();
?>
<div class="footer border-bottom center">
	<div>
		<center>ServerAion Web 1.3 &copy; 2014 - 2016 <a href="" target="_blank"> </a></center>
	</div>
</div>

</body>
</html>