<?php
// ServerAion Web by Pr00f & Sky (serveraion.ru)
require "header.php";
?>

<div class="case">
	<div class="content">
		<div class="list">
			<div class="news-title"><?php echo $lang['topRich']; ?></div>
			<?php require "modules/rich_m.php";?>
			</table>
		</div>
	</div>
    
<?php require "sidebar.php"; ?>
</div>

<?php require "footer.php"; ?>